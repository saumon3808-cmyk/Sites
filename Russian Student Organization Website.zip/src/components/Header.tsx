import { Button } from "./ui/button";
import { Menu, X, Search, User } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
              <span className="text-primary-foreground text-lg font-bold">РС</span>
            </div>
            <div className="hidden sm:block">
              <div className="text-xs text-muted-foreground uppercase tracking-wide">
                РОССИЙСКИЕ
              </div>
              <div className="text-xs text-muted-foreground uppercase tracking-wide -mt-1">
                СТУДЕНЧЕСКИЕ ОТРЯДЫ
              </div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <a href="#about" className="text-sm text-foreground hover:text-primary transition-colors font-medium">
              О нас
            </a>
            <a href="#events" className="text-sm text-foreground hover:text-primary transition-colors font-medium">
              Новости
            </a>
            <a href="#members" className="text-sm text-foreground hover:text-primary transition-colors font-medium">
              Будь с нами!
            </a>
            <a href="#contact" className="text-sm text-foreground hover:text-primary transition-colors font-medium">
              Контакты
            </a>
            <a href="#" className="text-sm text-foreground hover:text-primary transition-colors font-medium">
              Профобучение
            </a>
          </nav>

          {/* Search and User Actions */}
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="icon" className="hidden md:flex">
              <Search size={18} />
            </Button>
            <Button variant="outline" size="sm" className="hidden md:flex items-center space-x-2">
              <User size={16} />
              <span className="text-sm">Личный кабинет</span>
            </Button>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-4">
              <a 
                href="#about" 
                className="text-sm text-foreground hover:text-primary transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                О нас
              </a>
              <a 
                href="#events" 
                className="text-sm text-foreground hover:text-primary transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Новости
              </a>
              <a 
                href="#members" 
                className="text-sm text-foreground hover:text-primary transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Будь с нами!
              </a>
              <a 
                href="#contact" 
                className="text-sm text-foreground hover:text-primary transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Контакты
              </a>
              <a 
                href="#" 
                className="text-sm text-foreground hover:text-primary transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Профобучение
              </a>
              <div className="pt-2 border-t border-gray-200">
                <Button variant="outline" size="sm" className="w-full">
                  <User size={16} className="mr-2" />
                  Личный кабинет
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}