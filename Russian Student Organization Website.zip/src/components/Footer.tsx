import { Separator } from "./ui/separator";
import { Button } from "./ui/button";
import { Mail, Phone, MapPin, ArrowUp } from "lucide-react";

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-foreground text-background relative overflow-hidden">
      {/* Geometric background elements */}
      <div className="absolute top-8 right-8 opacity-10">
        <div className="grid grid-cols-4 gap-2">
          {Array.from({ length: 16 }).map((_, i) => (
            <div key={i} className={`w-6 h-6 ${i % 4 === 0 ? 'bg-primary' : i % 4 === 1 ? 'bg-white' : i % 4 === 2 ? 'bg-primary opacity-60' : 'bg-white opacity-60'} rounded`}></div>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Organization Info */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">РС</span>
              </div>
              <div>
                <h3 className="text-2xl font-bold">Русские Студенты</h3>
                <p className="text-gray-400 text-sm uppercase tracking-wide">
                  РОССИЙСКИЕ СТУДЕНЧЕСКИЕ ОТРЯДЫ
                </p>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed max-w-md">
              Объединение студентов российских университетов для изучения и сохранения 
              русской культуры, истории и литературы. Создаем будущее через наследие.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Mail size={16} className="text-primary" />
                <span className="text-gray-300 text-sm">info@russian-students.ru</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone size={16} className="text-primary" />
                <span className="text-gray-300 text-sm">+7 (495) 123-45-67</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin size={16} className="text-primary" />
                <span className="text-gray-300 text-sm">Москва, ул. Ломоносова, 27</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h4 className="text-lg font-bold">Навигация</h4>
            <ul className="space-y-3">
              {[
                { label: "О нас", href: "#about" },
                { label: "События", href: "#events" },
                { label: "Участники", href: "#members" },
                { label: "Контакты", href: "#contact" }
              ].map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="text-gray-300 hover:text-primary transition-colors duration-300 hover:translate-x-1 inline-block transform"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Programs */}
          <div className="space-y-6">
            <h4 className="text-lg font-bold">Наши программы</h4>
            <ul className="space-y-3 text-gray-300">
              <li>Литературные вечера</li>
              <li>Исторические лекции</li>
              <li>Культурные мероприятия</li>
              <li>Образовательные проекты</li>
              <li>Исследовательская работа</li>
            </ul>
          </div>
        </div>

        <Separator className="my-8 bg-gray-700" />

        {/* Bottom Section */}
        <div className="flex flex-col lg:flex-row justify-between items-center space-y-6 lg:space-y-0">
          <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-8">
            <div className="text-gray-400 text-sm">
              © 2025 Русские Студенты. Все права защищены.
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                Политика конфиденциальности
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                Условия использования
              </a>
            </div>
          </div>

          {/* Social Media */}
          <div className="flex items-center space-x-4">
            <span className="text-gray-400 text-sm">Следите за нами:</span>
            <div className="flex space-x-3">
              {[
                { name: "VK", color: "bg-blue-600" },
                { name: "IG", color: "bg-pink-600" },
                { name: "TG", color: "bg-blue-400" },
                { name: "YT", color: "bg-red-600" }
              ].map((social, index) => (
                <a key={index} href="#" className="group">
                  <div className={`w-8 h-8 ${social.color} rounded flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <span className="text-white text-xs font-bold">{social.name}</span>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Back to Top */}
          <Button
            variant="outline"
            size="icon"
            className="border-gray-600 text-gray-400 hover:text-white hover:border-primary"
            onClick={scrollToTop}
          >
            <ArrowUp size={16} />
          </Button>
        </div>
      </div>
    </footer>
  );
}