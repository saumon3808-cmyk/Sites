import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ArrowDown, Hash } from "lucide-react";

export function HeroSection() {
  return (
    <section id="home" className="relative bg-gray-50 overflow-hidden">
      {/* Geometric Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Top left geometric pattern */}
        <div className="absolute top-8 left-8 grid grid-cols-4 gap-2 opacity-80">
          <div className="w-12 h-12 bg-primary rounded"></div>
          <div className="w-12 h-12 bg-primary rounded opacity-60"></div>
          <div className="w-12 h-12 bg-primary rounded"></div>
          <div className="w-12 h-12 bg-black rounded"></div>
          <div className="w-12 h-12 bg-primary rounded opacity-40"></div>
          <div className="w-12 h-12 bg-primary rounded"></div>
          <div className="w-12 h-12 bg-primary rounded opacity-80"></div>
          <div className="w-12 h-12 bg-black rounded"></div>
          <div className="w-12 h-12 bg-primary rounded"></div>
          <div className="w-12 h-12 bg-primary rounded opacity-60"></div>
          <div className="w-12 h-12 bg-black rounded opacity-80"></div>
          <div className="w-12 h-12 bg-white rounded border-2 border-primary"></div>
        </div>

        {/* Logo watermarks */}
        <div className="absolute top-20 left-1/4 opacity-10">
          <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center">
            <span className="text-white text-xl font-bold">hh</span>
          </div>
        </div>
        <div className="absolute top-20 left-1/3 opacity-20">
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
            <span className="text-white text-xs font-bold">ТРУДКРУТ</span>
          </div>
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-8 z-10 relative">
            <div className="space-y-6">
              <h1 className="text-6xl lg:text-7xl font-bold text-primary leading-none">
                работа
                <br />
                и лучшее лето
              </h1>
              
              <div className="flex items-center space-x-4 text-lg">
                <span>Мы с тобой свяжемся, только</span>
              </div>
              <div className="flex items-center space-x-4 text-lg">
                <span>оставь удобный способ на</span>
                <a href="#" className="text-primary underline font-medium">
                  rs.ru/rso
                </a>
              </div>
            </div>

            {/* Arrow pointing down */}
            <div className="flex items-center">
              <div className="w-12 h-12 bg-primary rounded flex items-center justify-center">
                <ArrowDown className="text-white" size={24} />
              </div>
            </div>
          </div>

          {/* Right Content */}
          <div className="relative">
            {/* Social Media CTA Box */}
            <div className="absolute top-0 right-0 z-20 bg-primary text-white p-6 rounded-lg max-w-xs">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-xl font-bold mb-2">
                    смотри самое
                    <br />
                    интересное
                    <br />
                    у нас в соцсетях
                  </h3>
                </div>
                <div className="flex space-x-2">
                  <div className="w-8 h-8 bg-white bg-opacity-20 rounded flex items-center justify-center">
                    <div className="w-4 h-4 bg-white rounded-full"></div>
                  </div>
                  <div className="w-8 h-8 bg-black rounded flex items-center justify-center">
                    <Hash className="text-white" size={16} />
                  </div>
                </div>
              </div>
            </div>

            {/* Main Image */}
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1607013251379-e6eecfffe234?auto=format&fit=crop&w=800&q=80"
                alt="Студент в рабочей одежде"
                className="w-full h-96 lg:h-[500px] object-cover rounded-2xl"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom geometric elements */}
      <div className="absolute bottom-8 left-8 grid grid-cols-4 gap-2 opacity-60">
        <div className="w-8 h-8 bg-primary rounded"></div>
        <div className="w-8 h-8 bg-blue-300 rounded"></div>
        <div className="w-8 h-8 bg-primary rounded"></div>
        <div className="w-8 h-8 bg-black rounded"></div>
        <div className="w-8 h-8 bg-blue-400 rounded"></div>
        <div className="w-8 h-8 bg-primary rounded"></div>
        <div className="w-8 h-8 bg-primary rounded opacity-60"></div>
        <div className="w-8 h-8 bg-black rounded"></div>
      </div>
    </section>
  );
}