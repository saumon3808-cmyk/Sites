import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { Mail, Phone, MapPin, Clock, Send, MessageCircle } from "lucide-react";
import { useState } from "react";

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    alert("Спасибо за ваше сообщение! Мы свяжемся с вами в ближайшее время.");
    setFormData({ name: "", email: "", message: "" });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const contactInfo = [
    {
      icon: Mail,
      title: "Email",
      items: ["info@russian-students.ru", "culture@russian-students.ru"]
    },
    {
      icon: Phone,
      title: "Телефон",
      items: ["+7 (495) 123-45-67", "+7 (812) 987-65-43"]
    },
    {
      icon: MapPin,
      title: "Главный офис",
      items: ["г. Москва, ул. Ломоносова, 27", "МГУ, Гуманитарный корпус, к. 1054"]
    },
    {
      icon: Clock,
      title: "Часы работы",
      items: ["Пн-Пт: 10:00 - 19:00", "Сб: 11:00 - 17:00", "Вс: выходной"]
    }
  ];

  return (
    <section id="contact" className="py-24 bg-gray-50 relative overflow-hidden">
      {/* Geometric background elements */}
      <div className="absolute top-20 left-20 opacity-5">
        <div className="grid grid-cols-3 gap-4">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className={`w-16 h-16 ${i % 3 === 0 ? 'bg-primary' : i % 3 === 1 ? 'bg-black' : 'bg-primary opacity-60'} rounded`}></div>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-20">
          <div className="inline-block mb-6">
            <Badge variant="secondary" className="text-sm px-4 py-2 bg-primary/10 text-primary border-0">
              КОНТАКТЫ
            </Badge>
          </div>
          <h2 className="text-5xl lg:text-6xl font-bold mb-8 text-foreground leading-tight">
            Свяжитесь
            <br />
            <span className="text-primary">с нами</span>
          </h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-xl text-muted-foreground leading-relaxed">
              У вас есть вопросы или хотите присоединиться? Мы всегда рады новым единомышленникам!
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-12 mb-20">
          {/* Contact Information Cards */}
          {contactInfo.map((contact, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 group">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                  <contact.icon className="w-8 h-8 text-primary group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-xl font-bold mb-4 text-foreground">{contact.title}</h3>
                <div className="space-y-2">
                  {contact.items.map((item, itemIndex) => (
                    <p key={itemIndex} className="text-muted-foreground">{item}</p>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <div className="bg-white rounded-3xl p-10 shadow-xl relative overflow-hidden">
            {/* Geometric decoration */}
            <div className="absolute top-6 right-6 opacity-10">
              <div className="grid grid-cols-2 gap-2">
                <div className="w-8 h-8 bg-primary rounded"></div>
                <div className="w-8 h-8 bg-primary rounded opacity-60"></div>
                <div className="w-8 h-8 bg-black rounded"></div>
                <div className="w-8 h-8 bg-primary rounded opacity-40"></div>
              </div>
            </div>

            <div className="flex items-center space-x-3 mb-8">
              <MessageCircle className="w-8 h-8 text-primary" />
              <h3 className="text-3xl font-bold text-foreground">Напишите нам</h3>
            </div>
            
            <p className="text-muted-foreground mb-8">
              Оставьте сообщение, и мы обязательно вам ответим в течение 24 часов
            </p>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label htmlFor="name" className="text-sm font-medium text-foreground">Имя *</label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Ваше имя"
                  className="h-12 bg-gray-50 border-0 focus:ring-2 focus:ring-primary"
                  required
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium text-foreground">Email *</label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="your.email@example.com"
                  className="h-12 bg-gray-50 border-0 focus:ring-2 focus:ring-primary"
                  required
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-medium text-foreground">Сообщение *</label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Расскажите, что вас интересует..."
                  rows={6}
                  className="bg-gray-50 border-0 focus:ring-2 focus:ring-primary resize-none"
                  required
                />
              </div>

              <Button type="submit" size="lg" className="w-full bg-primary hover:bg-primary/90">
                <Send className="w-5 h-5 mr-2" />
                Отправить сообщение
              </Button>
            </form>
          </div>

          {/* Social Media and Additional Info */}
          <div className="space-y-8">
            {/* Social Media */}
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-6 text-foreground">Мы в социальных сетях</h3>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { name: "ВКонтакте", color: "bg-blue-600", icon: "VK" },
                    { name: "Instagram", color: "bg-pink-600", icon: "IG" },
                    { name: "Telegram", color: "bg-blue-400", icon: "TG" },
                    { name: "YouTube", color: "bg-red-600", icon: "YT" }
                  ].map((social, index) => (
                    <Button key={index} variant="outline" className="justify-start h-12 group hover:border-primary" asChild>
                      <a href="#" target="_blank" rel="noopener noreferrer">
                        <div className={`w-6 h-6 ${social.color} rounded mr-3 flex items-center justify-center group-hover:scale-110 transition-transform`}>
                          <span className="text-white text-xs font-bold">{social.icon}</span>
                        </div>
                        {social.name}
                      </a>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* CTA Block */}
            <div className="bg-gradient-to-br from-primary to-blue-600 rounded-3xl p-8 text-white relative overflow-hidden">
              {/* Geometric decoration */}
              <div className="absolute top-4 right-4 opacity-20">
                <div className="grid grid-cols-2 gap-2">
                  <div className="w-8 h-8 bg-white rounded"></div>
                  <div className="w-8 h-8 bg-white rounded opacity-60"></div>
                  <div className="w-8 h-8 bg-white rounded opacity-40"></div>
                  <div className="w-8 h-8 bg-white rounded"></div>
                </div>
              </div>

              <h3 className="text-2xl font-bold mb-4">Хотите узнать больше?</h3>
              <p className="text-white/90 mb-6">
                Скачайте нашу презентацию о деятельности организации и возможностях для участников
              </p>
              <Button variant="secondary" className="bg-white text-primary hover:bg-gray-100">
                Скачать презентацию
              </Button>
            </div>

            {/* Quick Info */}
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <h3 className="text-xl font-bold mb-4 text-foreground">Быстрые ответы</h3>
                <div className="space-y-4 text-sm">
                  <div>
                    <h4 className="font-medium text-foreground mb-1">Как вступить в организацию?</h4>
                    <p className="text-muted-foreground">Заполните форму заявки и ждите приглашение на собеседование</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground mb-1">Есть ли вступительный взнос?</h4>
                    <p className="text-muted-foreground">Участие в организации бесплатное</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground mb-1">Можно ли участвовать удаленно?</h4>
                    <p className="text-muted-foreground">Да, многие мероприятия проходят онлайн</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}