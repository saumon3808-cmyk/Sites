import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Calendar, MapPin, Clock, Users, ArrowRight } from "lucide-react";

export function EventsSection() {
  const upcomingEvents = [
    {
      id: 1,
      title: "Вечер русской поэзии 'Серебряный век'",
      date: "20 января 2025",
      time: "19:00",
      location: "Литературное кафе 'Поэзия'",
      attendees: 75,
      image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&w=600&q=80",
      description: "Вечер, посвященный творчеству поэтов Серебряного века с чтением произведений и дискуссией.",
      status: "upcoming"
    },
    {
      id: 2,
      title: "Мастер-класс по каллиграфии",
      date: "28 января 2025",
      time: "16:00",
      location: "Арт-студия 'Традиция'",
      attendees: 20,
      image: "https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?auto=format&fit=crop&w=600&q=80",
      description: "Изучаем искусство русской каллиграфии и древнеславянского письма.",
      status: "few-spots"
    },
    {
      id: 3,
      title: "Лекция 'Русские художники-передвижники'",
      date: "10 февраля 2025", 
      time: "18:30",
      location: "Онлайн",
      attendees: 200,
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?auto=format&fit=crop&w=600&q=80",
      description: "Познавательная лекция о творчестве великих русских художников XIX века.",
      status: "upcoming"
    }
  ];

  const stats = [
    { number: "120+", label: "мероприятий проведено" },
    { number: "5000+", label: "участников за год" },
    { number: "25", label: "городов России" },
    { number: "50+", label: "партнерских организаций" }
  ];

  return (
    <section id="events" className="py-24 bg-gray-50 relative overflow-hidden">
      {/* Geometric background elements */}
      <div className="absolute top-32 left-20 opacity-5">
        <div className="grid grid-cols-3 gap-4">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className={`w-20 h-20 ${i % 3 === 0 ? 'bg-primary' : i % 3 === 1 ? 'bg-black' : 'bg-primary opacity-60'} rounded`}></div>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-20">
          <div className="inline-block mb-6">
            <Badge variant="secondary" className="text-sm px-4 py-2 bg-primary/10 text-primary border-0">
              МЕРОПРИЯТИЯ
            </Badge>
          </div>
          <h2 className="text-5xl lg:text-6xl font-bold mb-8 text-foreground leading-tight">
            События и
            <br />
            <span className="text-primary">активности</span>
          </h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-xl text-muted-foreground leading-relaxed">
              Присоединяйтесь к нашим мероприятиям и погрузитесь в богатую русскую культуру
            </p>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div key={index} className="text-center group">
              <div className="bg-white rounded-2xl p-8 shadow-lg group-hover:shadow-xl transition-shadow duration-300">
                <div className="text-4xl lg:text-5xl font-bold text-primary mb-2">{stat.number}</div>
                <div className="text-muted-foreground font-medium">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Upcoming Events */}
        <div className="mb-20">
          <div className="flex items-center justify-between mb-12">
            <h3 className="text-4xl font-bold text-foreground">Предстоящие события</h3>
            <Button variant="outline" className="hidden lg:flex items-center space-x-2">
              <span>Все события</span>
              <ArrowRight size={16} />
            </Button>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {upcomingEvents.map((event) => (
              <Card key={event.id} className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
                <div className="relative">
                  <ImageWithFallback
                    src={event.image}
                    alt={event.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge 
                      className={`${
                        event.status === 'few-spots' 
                          ? 'bg-orange-500 hover:bg-orange-600' 
                          : 'bg-green-500 hover:bg-green-600'
                      } text-white border-0`}
                    >
                      {event.status === 'few-spots' ? 'Мало мест' : 'Открыта регистрация'}
                    </Badge>
                  </div>
                  <div className="absolute top-4 right-4 bg-primary rounded-lg p-2">
                    <Calendar size={16} className="text-white" />
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <h4 className="text-xl font-bold mb-3 text-foreground line-clamp-2 group-hover:text-primary transition-colors">
                    {event.title}
                  </h4>
                  <p className="text-muted-foreground mb-4 line-clamp-2">{event.description}</p>
                  
                  <div className="space-y-2 text-sm mb-6">
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <Calendar size={14} />
                      <span>{event.date}</span>
                      <Clock size={14} className="ml-2" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <MapPin size={14} />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <Users size={14} />
                      <span>{event.attendees} участников</span>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    Зарегистрироваться
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-primary to-blue-600 rounded-3xl p-12 text-center text-white relative overflow-hidden">
          {/* Geometric decoration */}
          <div className="absolute top-6 right-6 opacity-20">
            <div className="grid grid-cols-2 gap-2">
              <div className="w-12 h-12 bg-white rounded"></div>
              <div className="w-12 h-12 bg-white rounded opacity-60"></div>
              <div className="w-12 h-12 bg-white rounded opacity-40"></div>
              <div className="w-12 h-12 bg-white rounded"></div>
            </div>
          </div>
          
          <h3 className="text-4xl font-bold mb-4">Не пропустите наши события!</h3>
          <p className="text-xl mb-8 text-white/90 max-w-2xl mx-auto">
            Подпишитесь на уведомления и будьте в курсе всех культурных мероприятий
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="secondary" size="lg" className="bg-white text-primary hover:bg-gray-100">
              Подписаться на новости
            </Button>
            <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-primary">
              Календарь событий
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}