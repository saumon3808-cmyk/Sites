import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Mail, Linkedin, Instagram, ArrowRight, CheckCircle } from "lucide-react";

export function MembersSection() {
  const leadership = [
    {
      name: "Александр Петров",
      role: "Президент",
      university: "МГУ, 4 курс",
      description: "Изучает русскую литературу, организует культурные мероприятия",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80"
    },
    {
      name: "Мария Иванова", 
      role: "Вице-президент",
      university: "СПбГУ, магистратура",
      description: "Историк искусства, курирует выставочные проекты",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?auto=format&fit=crop&w=400&q=80"
    },
    {
      name: "Екатерина Смирнова",
      role: "Руководитель культурных программ",
      university: "РГГУ, 3 курс",
      description: "Организует литературные вечера и театральные постановки",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=400&q=80"
    },
    {
      name: "Николай Васильев",
      role: "Координатор образовательных проектов",
      university: "МПГУ, аспирантура",
      description: "Филолог, ведет лекции по русской классической литературе",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=400&q=80"
    }
  ];

  const stats = [
    { value: "500+", label: "Активных участников" },
    { value: "1200+", label: "Выпускников" },
    { value: "25", label: "Университетов" },
    { value: "7", label: "Лет работы" }
  ];

  const benefits = [
    "Участие в эксклюзивных культурных мероприятиях",
    "Доступ к образовательным программам и мастер-классам",
    "Нетворкинг с единомышленниками и экспертами",
    "Возможности для личностного и профессионального роста",
    "Участие в исследовательских проектах",
    "Сертификаты и рекомендации для портфолио"
  ];

  return (
    <section id="members" className="py-24 bg-white relative overflow-hidden">
      {/* Geometric background elements */}
      <div className="absolute bottom-32 right-20 opacity-5">
        <div className="grid grid-cols-4 gap-3">
          {Array.from({ length: 16 }).map((_, i) => (
            <div key={i} className={`w-16 h-16 ${i % 4 === 0 ? 'bg-primary' : i % 4 === 1 ? 'bg-black' : i % 4 === 2 ? 'bg-primary opacity-60' : 'bg-primary opacity-30'} rounded`}></div>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-20">
          <div className="inline-block mb-6">
            <Badge variant="secondary" className="text-sm px-4 py-2 bg-primary/10 text-primary border-0">
              НАШЕ СООБЩЕСТВО
            </Badge>
          </div>
          <h2 className="text-5xl lg:text-6xl font-bold mb-8 text-foreground leading-tight">
            Участники и
            <br />
            <span className="text-primary">команда</span>
          </h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-xl text-muted-foreground leading-relaxed">
              Познакомьтесь с нашей командой и узнайте о нашем растущем сообществе единомышленников
            </p>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div key={index} className="text-center group">
              <div className="bg-gradient-to-br from-primary to-blue-600 rounded-2xl p-8 text-white group-hover:scale-105 transition-transform duration-300">
                <div className="text-4xl lg:text-5xl font-bold mb-2">{stat.value}</div>
                <div className="text-white/90 font-medium">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Leadership Team */}
        <div className="mb-20">
          <div className="flex items-center justify-between mb-12">
            <h3 className="text-4xl font-bold text-foreground">Руководящая команда</h3>
            <Button variant="outline" className="hidden lg:flex items-center space-x-2">
              <span>Вся команда</span>
              <ArrowRight size={16} />
            </Button>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {leadership.map((member, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group overflow-hidden">
                <div className="relative">
                  <ImageWithFallback
                    src={member.image}
                    alt={member.name}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute bottom-4 left-4 right-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8 bg-white/20 hover:bg-white/30">
                        <Mail size={14} />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 bg-white/20 hover:bg-white/30">
                        <Linkedin size={14} />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 bg-white/20 hover:bg-white/30">
                        <Instagram size={14} />
                      </Button>
                    </div>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <h4 className="text-xl font-bold mb-2 text-foreground">{member.name}</h4>
                  <Badge variant="outline" className="mb-3 border-primary text-primary">{member.role}</Badge>
                  <p className="text-sm text-muted-foreground mb-3">{member.university}</p>
                  <p className="text-sm text-muted-foreground">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Join Us Section */}
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div>
              <h3 className="text-4xl font-bold mb-6 text-foreground">Присоединяйтесь к нам!</h3>
              <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                Наша организация открыта для всех студентов, интересующихся русской культурой, 
                историей и литературой. Неважно, какую специальность вы изучаете — 
                каждый найдет здесь свое место в нашем дружном сообществе.
              </p>
            </div>

            <div className="space-y-4">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <CheckCircle size={20} className="text-primary mt-0.5 flex-shrink-0" />
                  <span className="text-muted-foreground">{benefit}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                Подать заявку
              </Button>
              <Button variant="outline" size="lg">
                Узнать больше
              </Button>
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-3xl p-10 relative overflow-hidden">
            {/* Geometric decoration */}
            <div className="absolute top-6 right-6 opacity-20">
              <div className="grid grid-cols-3 gap-2">
                <div className="w-8 h-8 bg-primary rounded"></div>
                <div className="w-8 h-8 bg-primary rounded opacity-60"></div>
                <div className="w-8 h-8 bg-black rounded"></div>
                <div className="w-8 h-8 bg-primary rounded opacity-40"></div>
                <div className="w-8 h-8 bg-primary rounded"></div>
                <div className="w-8 h-8 bg-primary rounded opacity-80"></div>
              </div>
            </div>
            
            <h4 className="text-2xl font-bold mb-8 text-foreground">Требования для участия</h4>
            
            <div className="space-y-6">
              <div className="bg-white rounded-2xl p-6 shadow-sm">
                <h5 className="font-bold text-lg mb-2 text-foreground">Для кого</h5>
                <p className="text-muted-foreground">
                  Студенты любых специальностей и курсов российских университетов
                </p>
              </div>
              
              <div className="bg-white rounded-2xl p-6 shadow-sm">
                <h5 className="font-bold text-lg mb-2 text-foreground">Что получите</h5>
                <p className="text-muted-foreground">
                  Знания, культурное развитие, новых друзей и возможности для роста
                </p>
              </div>
              
              <div className="bg-white rounded-2xl p-6 shadow-sm">
                <h5 className="font-bold text-lg mb-2 text-foreground">Обязательства</h5>
                <p className="text-muted-foreground">
                  Активное участие в проектах по интересам и соблюдение ценностей организации
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}