import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Heart, BookOpen, Users, Globe } from "lucide-react";

export function AboutSection() {
  const values = [
    {
      icon: Heart,
      title: "Сохранение наследия",
      description: "Изучаем и передаем русские традиции и культурные ценности"
    },
    {
      icon: BookOpen,
      title: "Образование",
      description: "Организуем лекции по истории, литературе и искусству России"
    },
    {
      icon: Users,
      title: "Единство",
      description: "Создаем братскую атмосферу для всех участников"
    },
    {
      icon: Globe,
      title: "Культурный диалог",
      description: "Знакомим с русской культурой представителей других народов"
    }
  ];

  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      {/* Geometric background elements */}
      <div className="absolute top-20 right-20 opacity-10">
        <div className="grid grid-cols-3 gap-3">
          <div className="w-16 h-16 bg-primary rounded"></div>
          <div className="w-16 h-16 bg-primary rounded opacity-60"></div>
          <div className="w-16 h-16 bg-black rounded"></div>
          <div className="w-16 h-16 bg-primary rounded opacity-40"></div>
          <div className="w-16 h-16 bg-primary rounded"></div>
          <div className="w-16 h-16 bg-primary rounded opacity-80"></div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-20">
          <div className="inline-block mb-6">
            <Badge variant="secondary" className="text-sm px-4 py-2 bg-primary/10 text-primary border-0">
              О НАШЕЙ ОРГАНИЗАЦИИ
            </Badge>
          </div>
          <h2 className="text-5xl lg:text-6xl font-bold mb-8 text-foreground leading-tight">
            Кто мы и чем
            <br />
            <span className="text-primary">занимаемся</span>
          </h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-xl text-muted-foreground leading-relaxed">
              "Русские Студенты" — это студенческая организация, основанная в 2018 году 
              с целью объединения молодежи, интересующейся русской культурой, историей и литературой.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {values.map((value, index) => (
            <Card key={index} className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 group">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                  <value.icon className="w-8 h-8 text-primary group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-xl font-bold mb-4 text-foreground">{value.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{value.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div>
              <h3 className="text-4xl font-bold mb-6 text-foreground">Наша миссия</h3>
              <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                Мы стремимся сохранить и развивать русскую культуру в университетской среде, 
                создавая мосты между академическими знаниями и живой традицией.
              </p>
            </div>

            <div className="space-y-6">
              {[
                {
                  number: "01",
                  title: "Культурные программы",
                  description: "Литературные вечера, концерты и выставки"
                },
                {
                  number: "02", 
                  title: "Образовательные проекты",
                  description: "Лекции, семинары и дискуссионные клубы"
                },
                {
                  number: "03",
                  title: "Исследовательская деятельность", 
                  description: "Изучаем историю и современность русской культуры"
                }
              ].map((item, index) => (
                <div key={index} className="flex items-start space-x-6 group">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <span className="text-white font-bold text-sm">{item.number}</span>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold mb-2 text-foreground">{item.title}</h4>
                    <p className="text-muted-foreground">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-primary to-blue-600 p-10 rounded-3xl text-white relative overflow-hidden">
            {/* Geometric decoration */}
            <div className="absolute top-4 right-4 opacity-20">
              <div className="grid grid-cols-2 gap-2">
                <div className="w-8 h-8 bg-white rounded"></div>
                <div className="w-8 h-8 bg-white rounded opacity-60"></div>
                <div className="w-8 h-8 bg-white rounded opacity-40"></div>
                <div className="w-8 h-8 bg-white rounded"></div>
              </div>
            </div>
            
            <h3 className="text-3xl font-bold mb-8">Наши достижения</h3>
            <div className="space-y-6">
              {[
                {
                  year: "2024",
                  achievement: "Организовали Всероссийский форум русской культуры"
                },
                {
                  year: "2023",
                  achievement: "Запустили проект \"Живая литература\" в 20 университетах"
                },
                {
                  year: "2022",
                  achievement: "Получили грант на исследование современной русской поэзии"
                }
              ].map((item, index) => (
                <div key={index} className="border-l-4 border-white pl-6">
                  <h4 className="font-bold text-lg mb-2">{item.year} год</h4>
                  <p className="text-white/90">{item.achievement}</p>
                </div>
              ))}
            </div>
            
            <Button variant="secondary" className="mt-8 bg-white text-primary hover:bg-gray-100">
              Узнать больше
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}