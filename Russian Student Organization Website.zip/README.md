
  # Russian Student Organization Website

  This is a code bundle for Russian Student Organization Website. The original project is available at https://www.figma.com/design/JJOzRs9QW2oWeYSkK767BF/Russian-Student-Organization-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  